package nss.util;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

public class ReportGenerator {
	
	public static void generate() {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		try {
			FileWriter fw = new FileWriter("reports/report" + timeStamp + ".txt");
			//fw.write(text);
			//fw.flush();
			//fw.close();
			//create a buffered reader that connects to the console, we use it so we can read lines
		    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		    //read a line from the console
		    String lineFromInput = in.readLine();

		    //create an print writer for writing to a file
		    //PrintWriter out = new PrintWriter(fw);

		    //output to the file a line
		    fw.write(lineFromInput);

		    //close the file (VERY IMPORTANT!)
		    fw.flush();
		    fw.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

}
