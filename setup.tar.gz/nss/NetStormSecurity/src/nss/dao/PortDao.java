package nss.dao;

import nss.pojo.Port;
import nss.db.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PortDao {
	public static void main(String[] args) {
		ArrayList<Port> testung = PortDao.getAll();

		for (Port temp : testung) {
			System.out.println(temp.toString());
		}
		testung = PortDao.getWhereMAc("30:D3:2D:C7:F8:6E");
		for (Port temp : testung) {
			System.out.println("dasa  "+temp.toString());
		}
	}

	private static Port mapRow(ResultSet rSet) throws SQLException {
		return new Port(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getString(4), rSet.getString(5),
				rSet.getInt(6), rSet.getString(7));
	}

	public static ArrayList<Port> getAll() {

		ArrayList<Port> list = new ArrayList<Port>();

		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.port");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	
	
	public static ArrayList<Port> getWhereMAc(String mac){
		ArrayList<Port> list = new ArrayList<Port>();
		Connection c = DbConnection.getConnection();
		try {
			PreparedStatement pst = c.prepareStatement("select * from nssdb.port where device_mac = ?", PreparedStatement.RETURN_GENERATED_KEYS);
			pst.setString(1, mac);
			ResultSet rset = pst.executeQuery();
			if(rset.next()) {
				list.add(mapRow(rset));
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
}
