package nss.main;

import java.time.Instant;
import java.util.ArrayList;

import nss.db.AutomaticScanParserDao;
import nss.db.PenetrationTestDao;
import nss.function.NetworkScanner;
import nss.function.PenetrationTest;
import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Penetrationtest;
import nss.pojo.Port;
import nss.util.ReportParser;

public class Application {
	
	public static void penetrateAndInsertData(String macAddress, String type) {
		PenetrationTest.penetrateTarget(type, macAddress);
		boolean reportFound = false;
		while(!reportFound) {
			try {
				String penetrationData = ReportParser.parsePentrationData();
				Penetrationtest pt = new Penetrationtest(-1, type, penetrationData, (int)Instant.now().getEpochSecond(), macAddress);
				PenetrationTestDao.insertPenetrationData(pt);
			} finally {
				reportFound = true;
			}
		}
	}
	
	public static void scanAndInsertData(String type, String address) {
		if(type.equals("automatic")) {
			NetworkScanner.automaticScan();
			boolean reportFound = false;
			while(!reportFound) {
				try {
					ArrayList<ArrayList<Object>> list = ReportParser.parseAutomaticScan();
					ArrayList<Device> deviceList = new ArrayList<>();
					ArrayList<IpAddress> ipAddressList = new ArrayList<>();
					ArrayList<Port> portList = new ArrayList<>();
					if(list.isEmpty()) {
						System.out.println("Is Empty");
					} else {
						for(ArrayList<Object> temp : list) {
							for(Object o : temp) {
								if(o.getClass().equals(Device.class)) {
									Device td = (Device) o;
									deviceList.add(td);
								} else if(o.getClass().equals(IpAddress.class)) {
									IpAddress ip = (IpAddress) o;
									ipAddressList.add(ip);
								} else if(o.getClass().equals(Port.class)) {
									Port p = (Port) o;
									portList.add(p);
								} else {
									continue;
								}
							}
						}
					}
					for(Device d : deviceList) {
						AutomaticScanParserDao.insertUpdateDevice(d);
					}
					
					for(IpAddress ip : ipAddressList) {
						AutomaticScanParserDao.insertUpdateIpAddress(ip);
					}
					
					for(Port p : portList) {
						AutomaticScanParserDao.insertUpdatePorts(p);
					}
				} finally {
					reportFound = true;
				}
			}
		} else if(type.equals("manuell")) {
			NetworkScanner.manuellScan(address, 1);
			boolean reportFound = false;
			while(!reportFound) {
				try {
					ArrayList<ArrayList<Object>> list = ReportParser.parseAutomaticScan();
					ArrayList<Device> deviceList = new ArrayList<>();
					ArrayList<IpAddress> ipAddressList = new ArrayList<>();
					ArrayList<Port> portList = new ArrayList<>();
					if(list.isEmpty()) {
						System.out.println("Is Empty");
					} else {
						for(ArrayList<Object> temp : list) {
							for(Object o : temp) {
								if(o.getClass().equals(Device.class)) {
									Device td = (Device) o;
									deviceList.add(td);
								} else if(o.getClass().equals(IpAddress.class)) {
									IpAddress ip = (IpAddress) o;
									ipAddressList.add(ip);
								} else if(o.getClass().equals(Port.class)) {
									Port p = (Port) o;
									portList.add(p);
								} else {
									continue;
								}
							}
						}
					}
					for(Device d : deviceList) {
						AutomaticScanParserDao.insertUpdateDevice(d);
					}
					
					for(IpAddress ip : ipAddressList) {
						AutomaticScanParserDao.insertUpdateIpAddress(ip);
					}
					
					for(Port p : portList) {
						AutomaticScanParserDao.insertUpdatePorts(p);
					}
				} finally {
					reportFound = true;
				}
			}
		}
	}

}
