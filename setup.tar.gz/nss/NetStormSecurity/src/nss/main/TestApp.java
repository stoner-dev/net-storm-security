package nss.main;

public class TestApp {
	
	public static void main(String[] args) {
		Application.scanAndInsertData("manuell", "localhost");
	}

}
