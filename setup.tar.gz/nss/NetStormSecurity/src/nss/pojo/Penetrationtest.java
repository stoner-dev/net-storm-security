package nss.pojo;

public class Penetrationtest {

	private int idpenetrationtest;
	private String type;
	private String data;
	private int timestamp;
	private String device_mac;
	
	public Penetrationtest(int idpenetrationtest, String type, String data, int timestamp, String device_mac) {
		this.idpenetrationtest = idpenetrationtest;
		this.type = type;
		this.data = data;
		this.timestamp = timestamp;
		this.device_mac = device_mac;
	}

	public int getIdpenetrationtest() {
		return idpenetrationtest;
	}

	public void setIdpenetrationtest(int idpenetrationtest) {
		this.idpenetrationtest = idpenetrationtest;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public String getDevice_mac() {
		return device_mac;
	}

	public void setDevice_mac(String device_mac) {
		this.device_mac = device_mac;
	}

	@Override
	public String toString() {
		return "Penetrationtest [idpenetrationtest=" + idpenetrationtest + ", type=" + type + ", data=" + data
				+ ", timestamp=" + timestamp + ", device_mac=" + device_mac + "]";
	}
	
}
