package nss.main;

import java.util.ArrayList;

import nss.function.NetworkScanner;
import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Ports;
import nss.util.ReportParser;

public class TestApp {
	
	public static void main(String[] args) {
		
		//NetworkScanner ns = new NetworkScanner();
		//ns.automaticScan();
		
		ArrayList<ArrayList<Object>> list = ReportParser.parseAutomaticScan();
		
		if(list.isEmpty()) {
			System.out.println("Is Empty");
		} else {
			for(ArrayList<Object> temp : list) {
				System.out.println(temp.size());
			}
		}
	}

}
