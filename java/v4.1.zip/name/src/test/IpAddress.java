package test;

public class IpAddress {

	private int id;
	private String ipadress;
	private String timestamp;
	private int for_iddevice;
	
	

	public IpAddress(int id, String ipadress, String timestamp, int for_iddevice) {
		super();
		this.id = id;
		this.ipadress = ipadress;
		this.timestamp = timestamp;
		this.for_iddevice = for_iddevice;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIpadress() {
		return ipadress;
	}
	public void setIpadress(String ipadress) {
		this.ipadress = ipadress;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public int getFor_iddevice() {
		return for_iddevice;
	}
	public void setFor_iddevice(int for_iddevice) {
		this.for_iddevice = for_iddevice;
	}
	@Override
	public String toString() {
		return "IpAddress [id=" + id + ", ipadress=" + ipadress + ", timestamp=" + timestamp + ", for_iddevice="
				+ for_iddevice + "]";
	}
	
	
	
}
