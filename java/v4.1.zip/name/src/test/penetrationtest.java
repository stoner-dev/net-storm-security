package test;

public class penetrationtest {

	private int idpenetrationtest;
	private String type;
	private String data;
	private int timestamp;
	private int for_iddevices;

	
	public penetrationtest(int idpenetrationtest, String type, String data, int timestamp, int for_iddevices) {
		super();
		this.idpenetrationtest = idpenetrationtest;
		this.type = type;
		this.data = data;
		this.timestamp = timestamp;
		this.for_iddevices = for_iddevices;
	}
	
	
	
	public int getIdpenetrationtest() {
		return idpenetrationtest;
	}
	public void setIdpenetrationtest(int idpenetrationtest) {
		this.idpenetrationtest = idpenetrationtest;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	public int getFor_iddevices() {
		return for_iddevices;
	}
	public void setFor_iddevices(int for_iddevices) {
		this.for_iddevices = for_iddevices;
	}
	@Override
	public String toString() {
		return "penetrationtest [idpenetrationtest=" + idpenetrationtest + ", type=" + type + ", data=" + data
				+ ", timestamp=" + timestamp + ", for_iddevices=" + for_iddevices + "]";
	}
	
	
}
