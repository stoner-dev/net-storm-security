package test;

public class Ports {
		
	private int idports;
	private String port;
	private String service;
	private String state;
	private String version;
	private int timestamp;
	private String extended_port_info;
	private int for_iddevices;
	

	
	public Ports(int idports, String port, String service, String state, String version, int timestamp,
			String extended_port_info, int for_iddevices) {
		super();
		this.idports = idports;
		this.port = port;
		this.service = service;
		this.state = state;
		this.version = version;
		this.timestamp = timestamp;
		this.extended_port_info = extended_port_info;
		this.for_iddevices = for_iddevices;
	}
	
	
	public int getIdports() {
		return idports;
	}
	public void setIdports(int idports) {
		this.idports = idports;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public int getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	public String getExtended_port_info() {
		return extended_port_info;
	}
	public void setExtended_port_info(String extended_port_info) {
		this.extended_port_info = extended_port_info;
	}
	public int getFor_iddevices() {
		return for_iddevices;
	}
	public void setFor_iddevices(int for_iddevices) {
		this.for_iddevices = for_iddevices;
	}
	@Override
	public String toString() {
		return "Ports [idports=" + idports + ", port=" + port + ", service=" + service + ", state=" + state
				+ ", version=" + version + ", timestamp=" + timestamp + ", extended_port_info=" + extended_port_info
				+ ", for_iddevices=" + for_iddevices + "]";
	}
	
	
	
	
	
}
