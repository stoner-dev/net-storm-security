package nss.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Port;

public class AutomaticScanParserDao {
	
	//Device ===========================================================================================
	
	public static ArrayList<Device> getAllDevices() {
		ArrayList<Device> result = new ArrayList<>();
		String sql = "select * from nssdb.device";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new Device(rst.getString(1), rst.getString(2), rst.getString(3), rst.getInt(4)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdateDevice(Device device) {
		String sqlInsert = "insert into nssdb.device (macaddress, status, os, timestamp) values (?,?,?,?)";
		String sqlUpdate = "update nssdb.device set status=?, timestamp=? where macaddress=?";
		
		ArrayList<Device> tempDList = getAllDevices();
		
		if(tempDList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, device.getMacaddress());
				pst.setString(2, device.getStatus());
				pst.setString(3, device.getOs());
				pst.setInt(4, device.getTimestamp());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			for(Device d : tempDList) {
				if(!d.getMacaddress().equals(null) || !d.getMacaddress().equals("")) {
					if(d.getMacaddress().equals(device.getMacaddress())) {
						try {
							Connection c = DbConnection.getConnection();
							PreparedStatement pst = c.prepareStatement(sqlUpdate);
							pst.setString(1, device.getStatus());
							pst.setInt(2, device.getTimestamp());
							pst.setString(3, device.getMacaddress());
							pst.executeUpdate();
						} catch(Exception e) {
							e.printStackTrace();
						}
						return;
					} else {
						continue;
					}
				} else {
					continue;
				}
			}
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, device.getMacaddress());
				pst.setString(2, device.getStatus());
				pst.setString(3, device.getOs());
				pst.setInt(4, device.getTimestamp());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//==================================================================================================
	
	//IP Address =======================================================================================
	
	public static ArrayList<IpAddress> getAllIpAddresses() {
		ArrayList<IpAddress> result = new ArrayList<>();
		String sql = "select * from nssdb.ipaddress";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new IpAddress(rst.getInt(1), rst.getString(2), rst.getInt(3), rst.getString(4)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdateIpAddress(IpAddress ipAddress) {
		String sqlInsert = "insert into nssdb.ipaddress (address, timestamp, device_mac) values (?,?,?)";
		String sqlUpdate = "update nssdb.ipaddress set address=?, timestamp=? where device_mac=?";
		
		ArrayList<IpAddress> tempIpList = getAllIpAddresses();
		
		if(tempIpList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, ipAddress.getAddress());
				pst.setInt(2, ipAddress.getTimestamp());
				pst.setString(3, ipAddress.getDevice_mac());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			for(IpAddress temp : tempIpList) {
				if(!temp.getDevice_mac().equals(null) || !temp.getDevice_mac().equals("")) {
					if(temp.getDevice_mac().equals(ipAddress.getDevice_mac())) {
						try {
							Connection c = DbConnection.getConnection();
							PreparedStatement pst = c.prepareStatement(sqlUpdate);
							pst.setString(1, ipAddress.getAddress());
							pst.setInt(2, ipAddress.getTimestamp());
							pst.setString(3, ipAddress.getDevice_mac());
							pst.executeUpdate();
						} catch(Exception e) {
							e.printStackTrace();
						}
						return;
					} else {
						continue;
					}
				} else {
					continue;
				}
			}
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, ipAddress.getAddress());
				pst.setInt(2, ipAddress.getTimestamp());
				pst.setString(3, ipAddress.getDevice_mac());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//==================================================================================================
	
	//Ports ============================================================================================
	
	public static ArrayList<Port> getAllPorts() {
		ArrayList<Port> result = new ArrayList<>();
		String sql = "select * from nssdb.port";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new Port(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getInt(6), rst.getString(7)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdatePorts(Port port) {
		String sqlInsert = "insert into nssdb.port (number, service, state, version, timestamp, device_mac) values (?,?,?,?,?,?)";
		String sqlUpdate = "update nssdb.port set state=?, timestamp=? where number=? and device_mac=?";
		
		ArrayList<Port> tempPList = getAllPorts();
		
		if(tempPList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, port.getNumber());
				pst.setString(2, port.getService());
				pst.setString(3, port.getState());
				pst.setString(4, port.getVersion());
				pst.setInt(5, port.getTimestamp());
				pst.setString(6, port.getDevice_mac());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			for(Port temp : tempPList) {
				if(!temp.getDevice_mac().equals(null) || !temp.getDevice_mac().equals("")) {
					if(temp.getDevice_mac().equals(port.getDevice_mac()) && temp.getNumber().equals(port.getNumber())) {
						try {
							Connection c = DbConnection.getConnection();
							PreparedStatement pst = c.prepareStatement(sqlUpdate);
							pst.setString(1, port.getState());
							pst.setInt(2, port.getTimestamp());
							pst.setString(3, port.getNumber());
							pst.setString(4, port.getDevice_mac());
							pst.executeUpdate();
						} catch(Exception e) {
							e.printStackTrace();
						}
						return;
					} else {
						continue;
					}
				} else {
					continue;
				}
			}
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, port.getNumber());
				pst.setString(2, port.getService());
				pst.setString(3, port.getState());
				pst.setString(4, port.getVersion());
				pst.setInt(5, port.getTimestamp());
				pst.setString(6, port.getDevice_mac());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
