package nss.pojo;

public class Device {
	
	private String macaddress;
	private String status;
	private String os;
	private int timestamp;
	
	public Device(String macaddress, String status, String os, int timestamp) {
		this.macaddress = macaddress;
		this.status = status;
		this.os = os;
		this.timestamp = timestamp;
	}

	public String getMacaddress() {
		return macaddress;
	}

	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Device [macaddress=" + macaddress + ", status=" + status + ", os=" + os + ", timestamp=" + timestamp
				+ "]";
	}

}