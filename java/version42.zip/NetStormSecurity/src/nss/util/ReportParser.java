package nss.util;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReportParser {
	
	public static void parse() {
		try {
			File inputFile = new File("reports/report.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile); 
			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			NodeList hostList = doc.getElementsByTagName("host");
			System.out.println("---------------------------");
			Node nNode = hostList.item(0).getFirstChild();
			Element eElement = (Element) nNode;
			System.out.println(eElement.getAttribute("state"));
//			for(int temp = 0; temp < hostList.getLength(); temp++) {
//				Node nNode = hostList.item(temp);
//				System.out.println("\nCurrent Element: " + nNode.getNodeName());
//				
//				System.out.println(nNode.getNodeName());
//			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
