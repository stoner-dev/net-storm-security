package test;

import nss.db.DbConnection;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(DbConnection.getConnection());
	}

}
