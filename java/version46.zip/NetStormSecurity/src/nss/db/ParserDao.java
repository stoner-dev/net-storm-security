package nss.db;

import java.util.ArrayList;

import nss.pojo.Device;

public class ParserDao {
	
	public static void insertDevices(ArrayList<Device> deviceList) {
		
	}

}
