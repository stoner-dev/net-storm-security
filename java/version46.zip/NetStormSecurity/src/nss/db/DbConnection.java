package nss.db;
import java.sql.*;

//public class DbConnection {
//	private static final String DEFAULT_USER = "root";
//	private static final String DEFAULT_PASSWORD = "";
//	
//	private static final String DEFAULT_SERVER = "localhost";
//	private static final int DEFAULT_PORT = 3306;
//	private static final String DEFAULT_SCHEMA = "test";
//	
//	private static Connection connection;
//	
//	
//	public static synchronized Connection getConnection() {
//		if(connection != null) {
//			return connection;
//		}else {
//			try {
//				Class.forName("com.mysql.jdbc.Driver");
//				String url = String.format("%s:%s/%s", DEFAULT_SERVER, DEFAULT_PORT, DEFAULT_SCHEMA);
//				String fullUrl = String.format("jdbc:mysql://%?useSSL=false", url);
//				connection = DriverManager.getConnection(fullUrl, DEFAULT_USER, DEFAULT_PASSWORD);
//			}catch(ClassNotFoundException e) {
//				System.out.println("JDBC-Driver not found");
//				e.printStackTrace();
//			}catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		return connection;
//	}
//	
//	
//	public static ResultSet executeQuery(String sql) throws SQLException{
//		Statement statement = getConnection().createStatement();
//		ResultSet rset = statement.executeQuery(sql);
//		return rset;
//	}
//	
//}

public class DbConnection {
	
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "root";
    private static final String DEFAULT_SERVER = "10.68.252.55";
    private static final int DEFAULT_PORT = 3306;
    private static final String DEFAULT_SCHEMA = "nssdb";
    private static Connection connection;

    public static Connection getConnection() {
        if (connection != null) {
            return connection;
        } else {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                String url = String.format("%s:%s/%s", DEFAULT_SERVER, DEFAULT_PORT, DEFAULT_SCHEMA);
                String fullURL = String.format("jdbc:mysql://%s?useSSL=false", url);
                connection = DriverManager.getConnection(fullURL, DEFAULT_USER, DEFAULT_PASSWORD);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void close() {
        try {
            if (connection != null)
                connection.close();
                connection = null;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

