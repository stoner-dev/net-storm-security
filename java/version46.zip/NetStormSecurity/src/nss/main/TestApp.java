package nss.main;

import nss.function.NetworkScanner;
import nss.util.ReportParser;

public class TestApp {
	
	public static void main(String[] args) {
		
		//NetworkScanner ns = new NetworkScanner();
		//ns.automaticScan();
		
		ReportParser.parseAutomaticScan();
	}

}
