package nss.pojo;

public class IpAddress {

	private int idipaddress;
	private String ipaddress;
	private int timestamp;
	private int for_iddevice;

	public IpAddress(int idipaddress, String ipadress, int timestamp, int for_iddevice) {
		this.idipaddress = idipaddress;
		this.ipaddress = ipadress;
		this.timestamp = timestamp;
		this.for_iddevice = for_iddevice;
	}
	
	
	public int getIdIpAddress() {
		return idipaddress;
	}
	
	public void setIdIpAddress(int idipaddress) {
		this.idipaddress = idipaddress;
	}
	
	public String getIpAddress() {
		return ipaddress;
	}
	
	public void setIpAdress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	
	public long getTimestamp() {
		return timestamp;
	}
	
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	public int getFor_iddevice() {
		return for_iddevice;
	}
	
	public void setFor_iddevice(int for_iddevice) {
		this.for_iddevice = for_iddevice;
	}
	
	@Override
	public String toString() {
		return "IpAddress [id=" + idipaddress + ", ipadress=" + ipaddress + ", timestamp=" + timestamp + ", for_iddevice="
				+ for_iddevice + "]";
	}
	
}
