package nss.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import nss.pojo.Device;

public class ParserDao {
	
	//Device ===========================================================================================
	
	public static ArrayList<Device> getAllDevices() {
		ArrayList<Device> result = new ArrayList<>();
		String sql = "select * from nssdb.device";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new Device(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdateDevice(Device device) {
		String sqlInsert = "insert into nssdb.device (iddevice, status, macaddress, os, timestamp) values (?,?,?,?,?)";
		String sqlUpdate = "update nssdb.device set status=?, timestamp=? where macaddress=?";
		
		ArrayList<Device> tempDList = getAllDevices();
		
		if(tempDList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//==================================================================================================

}
