package test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import nss.pojo.Ports;

public class PortDao {
	public static void main(String[] args) {
		ArrayList<Ports> testung = PortDao.getAll();

		for (Ports temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static Ports mapRow(ResultSet rSet) throws SQLException {
		return new Ports(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getString(4), rSet.getString(5));
	}

	public static ArrayList<Ports> getAll() {

		ArrayList<Ports> list = new ArrayList<Ports>();
		
		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.ports");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
}
