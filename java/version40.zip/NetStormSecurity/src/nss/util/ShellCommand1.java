package nss.util;

import java.io.File;
import java.io.IOException;

public class ShellCommand1 {
	
	public static void execute(File file) throws IOException, InterruptedException {

	    File tempScript = file;
	    
	    try {
	        ProcessBuilder pb = new ProcessBuilder("bash", tempScript.toString());
	        pb.inheritIO();
	        Process process = pb.start();
	        process.waitFor();
	    } finally {
	        tempScript.delete();
	    }
	}

}
