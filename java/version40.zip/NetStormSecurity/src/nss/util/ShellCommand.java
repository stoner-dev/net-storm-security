package nss.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class ShellCommand {
	
	public static void execute(File file) throws IOException, InterruptedException {

		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
	    File tempScript = file;
	    File tempOutput = new File("reports/report" + timeStamp + ".txt");
	    
	    try {
	        ProcessBuilder pb = new ProcessBuilder("bash", tempScript.toString());
	        pb.redirectOutput(tempOutput);
	        Process process = pb.start();
	        process.waitFor();
	    } finally {
	        tempScript.delete();
	    }
	}

}
