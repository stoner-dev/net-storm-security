package nss.function;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

import nss.util.ShellCommand;

public class PenetrationTest {
	
	private String address = "127.0.0.1";
	private int netmask;
	private String target;
	
	public PenetrationTest() {
		this.target = this.address;
	}
	
	public PenetrationTest(String address) {
		this.address = address;
		this.target = this.address;
	}
	
	public PenetrationTest(String address, int netmask) {
		this.address = address;
		this.netmask = netmask;
		this.target = this.address + "/" + String.valueOf(this.netmask);
	}
	
	public void smbLoginCheck() {
	    try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"use auxiliary/scanner/smb/smb_login; set RHOSTS " + target + "; set SMBUser victim; set SMBPass s3cr3t; set THREADS 50; run; exit\"");

		    printWriter.close();
		    
		    System.out.println("Running SMB Brute Force for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("SMB Brute Force done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}
	
	public void sshLoginCheck() {
		try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"use auxiliary/scanner/ssh/ssh_login; set RHOSTS " + target + "; set USERPASS_FILE resources/userpass_file.txt; set VERBOSE false; run; sessions -i 1; exit\"");

		    printWriter.close();

		    System.out.println("Running SSH Brute Force for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("SSH Brute Force done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}
	
	public void vncAuthenticationCheck() {
		try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("msfconsole -q -x \"use auxiliary/scanner/vnc/vnc_none_auth; set RHOSTS " + target + "; set THREADS 50; run; exit\"");

		    printWriter.close();

		    System.out.println("Running VNC Authetication Check for " + target + "...");

		    ShellCommand.execute(tempScript);
		    
		    System.out.println("VNC Authentication Check done for " + target + ". Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}

}
