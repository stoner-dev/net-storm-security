package nss.function;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

import nss.util.ShellCommand;
import nss.util.ShellCommand1;

public class NetworkScanner {
	
	private String address = "127.0.0.1";
	private int intensity = 0;
	
	public NetworkScanner() {
		
	}
	
	public NetworkScanner(String address) {
		this.address = address;
	}
	
	public NetworkScanner(String address, int intensity) {
		this.address = address;
		this.intensity = intensity;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public int getIntensity() {
		return intensity;
	}

	public void setIntensity(int intensity) {
		this.intensity = intensity;
	}

	public void automaticScan() {
	    try {
	    	File tempScript = File.createTempFile("script", null);

		    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
		    PrintWriter printWriter = new PrintWriter(streamWriter);

		    printWriter.println("#!/bin/bash");
		    printWriter.println("IFS=. read -r i1 i2 i3 i4 <<< $(hostname -I | cut -d ' ' -f 1)");
		    printWriter.println("IFS=. read -r m1 m2 m3 m4 <<< $(ifconfig | grep -w inet |grep -v 127.0.0.1| awk '{print $4}')");
		    printWriter.println("netaddress=$(printf \"%d.%d.%d.%d\\n\" \"$((i1 & m1))\" \"$((i2 & m2))\" \"$((i3 & m3))\" \"$((i4 & m4))\")");
		    printWriter.println("netmask=$(echo $(ip -o -f inet addr show | awk '/scope global/ {print $4}') | cut -d '/' -f 2)");
		    printWriter.println("target=$netaddress'/'$netmask");
		    printWriter.println("echo $(echo kali | sudo -S nmap -sV -T4 -O -F --version-light -oX - $target) > /home/kali/Desktop/NetStormSecurity/reports/report.xml");

		    printWriter.close();
		    
		    System.out.println("Running automatic Quick Scan Plus...");

		    ShellCommand1.execute(tempScript);
		    
		    System.out.println("Automatic Qick Scan Plus done. Report generated.");
		    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(InterruptedException e) {
	    	e.printStackTrace();
	    }
	}
	
	public void manuellScan() {
		if(intensity == 0) {
			try {
		    	File tempScript = File.createTempFile("script", null);

			    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
			    PrintWriter printWriter = new PrintWriter(streamWriter);

			    printWriter.println("#!/bin/bash");
			    printWriter.println("sudo nmap " + address);

			    printWriter.close();
			    
			    //System.out.println("Running Nmap Scan for " + address + "...");

			    ShellCommand1.execute(tempScript);
			    
			    //System.out.println("Nmap Scan done for " + address + ". Report generated.");
			    
		    } catch(IOException e) {
		    	e.printStackTrace();
		    } catch(InterruptedException e) {
		    	e.printStackTrace();
		    }
		} else if(intensity == 1) {
			try {
		    	File tempScript = File.createTempFile("script", null);

			    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
			    PrintWriter printWriter = new PrintWriter(streamWriter);

			    printWriter.println("#!/bin/bash");
			    printWriter.println("sudo nmap -sV -T4 -O -F --version-light " + address);

			    printWriter.close();

			    System.out.println("Running Quick Scan Plus for " + address + "...");

			    ShellCommand.execute(tempScript);
			    
			    System.out.println("Quick Scan Plus done for " + address + ". Report generated.");
			    
		    } catch(IOException e) {
		    	e.printStackTrace();
		    } catch(InterruptedException e) {
		    	e.printStackTrace();
		    }
		} else if(intensity == 2) {
			try {
		    	File tempScript = File.createTempFile("script", null);

			    Writer streamWriter = new OutputStreamWriter(new FileOutputStream(tempScript));
			    PrintWriter printWriter = new PrintWriter(streamWriter);

			    printWriter.println("#!/bin/bash");
			    printWriter.println("sudo nmap -T4 -A -v " + address);

			    printWriter.close();

			    System.out.println("Running Intense Scan for " + address + "...");

			    ShellCommand.execute(tempScript);
			    
			    System.out.println("Intense Scan done for " + address + ". Report generated.");
			    
		    } catch(IOException e) {
		    	e.printStackTrace();
		    } catch(InterruptedException e) {
		    	e.printStackTrace();
		    }
			
		}
	}

}
