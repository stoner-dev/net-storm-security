package nss.main;

import nss.function.NetworkScanner;
import nss.function.PenetrationTest;
import nss.util.ReportParser;

public class TestApp {
	
	public static void main(String[] args) {
		//NetworkScanner ns1 = new NetworkScanner();
		//ns1.automaticScan();
		
		//NetworkScanner ns2 = new NetworkScanner();
		//ns2.automaticScan();
		ReportParser.parse();
		
		//PenetrationTest pt = new PenetrationTest("192.168.8.0", 24);
		//pt.vncAuthenticationCheck();
	}

}
