package nss.util;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Ports;

public class ReportParser {
	
	public static ArrayList<ArrayList<Object>> parseAutomaticScan() {
		ArrayList<ArrayList<Object>> result = new ArrayList<>();
		
		ArrayList<Object> deviceList = new ArrayList<>();
		ArrayList<Object> ipAddressList = new ArrayList<>();
		ArrayList<Object> portsList = new ArrayList<>();
		
		try {
			File inputFile = new File("reports/report.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile); 
			doc.getDocumentElement().normalize();
			NodeList hostList = doc.getElementsByTagName("host");
			
			for(int i = 0; i < hostList.getLength(); i++) {
				long unixTime = Instant.now().getEpochSecond();
				int deviceID = (int) unixTime + i;
				Device tempDevice = new Device(deviceID, null, null, null, deviceID);
				IpAddress tempIp = new IpAddress(-1, null, 0, deviceID);
				
				Node nNode = hostList.item(i);
				NodeList nList = nNode.getChildNodes();
				
				Node nStatus = nList.item(2);
				Node nIpAddress = nList.item(3);
				Node nMacAddress = nList.item(4);
				Node nPorts = nList.item(6);
				Node nOS = nList.item(7);
				
				for(int j = 0; j < nList.getLength(); j=j+2) {
					Node nnNode = nList.item(j);
					
					if(nnNode.getNodeName().equals("status")) {
						nStatus = nnNode;
					} else if(nnNode.getNodeName().equals("address") && j == 2) {
						nIpAddress = nnNode;
					} else if(nnNode.getNodeName().equals("address") && j == 4) {
						nMacAddress = nnNode;
					} else if(nnNode.getNodeName().equals("ports")) {
						nPorts = nnNode;
					} else if(nnNode.getNodeName().equals("os")) {
						nOS = nnNode;
					} else {
						continue;
					}
				}
				
				Element eStatus = (Element) nStatus;
				Element eIpAddress = (Element) nIpAddress;
				Element eMacAddress = (Element) nMacAddress;
				//Element eOS = (Element) nOS;
				//Element eOSMatch = (Element) eOS.getElementsByTagName("osmatch");
				NodeList osList = nOS.getChildNodes();
				
				for(int j = 0; j < osList.getLength(); j++) {
					Node nnNode = osList.item(j);
					if(nnNode.getNodeName().equals("osmatch")) {
						tempDevice.setOs(((Element)nnNode).getAttribute("name"));
					}
				}
				
				//System.out.println("Status: state=" + eStatus.getAttribute("state") + ", reason=" + eStatus.getAttribute("reason"));
				//System.out.println("IP-Address: address=" + eIpAddress.getAttribute("addr"));
				//System.out.println("MAC-Address: address=" + eMacAddress.getAttribute("addr") + ", vendor=" + eMacAddress.getAttribute("vendor"));
				tempDevice.setStatus(eStatus.getAttribute("state"));
				tempDevice.setMacaddress(eMacAddress.getAttribute("addr"));
				//tempDevice.setOs(eOSMatch.getAttribute("name"));
				tempIp.setIpAdress(eIpAddress.getAttribute("addr"));
				tempIp.setTimestamp((int)Instant.now().getEpochSecond());
				
				deviceList.add(tempDevice);
				ipAddressList.add(tempIp);
				
				NodeList portList = nPorts.getChildNodes();
				
				//System.out.println("Ports: ");
				for(int j = 1; j < portList.getLength(); j++) {
					Ports tempPort = new Ports(-1, null, null, null, null, 0, null, deviceID);
					
					Node nnNode = portList.item(j);
					NodeList innerPortList = nnNode.getChildNodes();
					//System.out.println("Protocol: " + eeElement.getAttribute("protocol"));
					//System.out.println("Port: " + eeElement.getAttribute("portid"));
					for(int k = 0; k < innerPortList.getLength(); k++) {
						tempPort.setTimestamp((int)Instant.now().getEpochSecond());
						
						Node nnnNode = innerPortList.item(k);
						Element eeElement = (Element) nnNode;
						Element eeeElement = (Element) nnnNode;
						//System.out.println("	Protocol: " + eeElement.getAttribute("protocol"));
						//System.out.println("	Port Number: " + eeElement.getAttribute("portid"));
						tempPort.setPort(eeElement.getAttribute("portid"));
						if(nnnNode.getNodeName().equals("state")) {
							//System.out.println("	State: " + eeeElement.getAttribute("state"));
							//System.out.println("	Reason: " + eeeElement.getAttribute("reason"));
							tempPort.setState(eeeElement.getAttribute("state"));
						} else if(nnnNode.getNodeName().equals("service")) {
							//System.out.println("	Name: " + eeeElement.getAttribute("name"));
							//System.out.println("	Version: " + eeeElement.getAttribute("version"));
							tempPort.setService(eeeElement.getAttribute("name"));
							tempPort.setVersion(eeeElement.getAttribute("version"));
						}
					}
					portsList.add(tempPort);
				}
			}
			
			result.add(deviceList);
			result.add(ipAddressList);
			result.add(portsList);
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
