package nss.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import nss.pojo.Device;
import nss.pojo.IpAddress;

public class ParserDao {
	
	//Device ===========================================================================================
	
	public static ArrayList<Device> getAllDevices() {
		ArrayList<Device> result = new ArrayList<>();
		String sql = "select * from nssdb.device";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new Device(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdateDevice(Device device) {
		String sqlInsert = "insert into nssdb.device (iddevice, status, macaddress, os, timestamp) values (?,?,?,?,?)";
		String sqlUpdate = "update nssdb.device set status=?, timestamp=? where macaddress=?";
		
		ArrayList<Device> tempDList = getAllDevices();
		
		if(tempDList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setInt(1, device.getIddevices());
				pst.setString(2, device.getStatus());
				pst.setString(3, device.getMacaddress());
				pst.setString(4, device.getOs());
				pst.setInt(5, device.getTimestamp());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			for(Device d : tempDList) {
				if(!d.getMacaddress().equals(null) || !d.getMacaddress().equals("")) {
					if(d.getMacaddress().equals(device.getMacaddress())) {
						try {
							Connection c = DbConnection.getConnection();
							PreparedStatement pst = c.prepareStatement(sqlUpdate);
							pst.setString(1, device.getStatus());
							pst.setInt(2, device.getTimestamp());
							pst.setString(3, device.getMacaddress());
							pst.executeUpdate();
						} catch(Exception e) {
							e.printStackTrace();
						}
						return;
					} else {
						continue;
					}
				} else {
					continue;
				}
			}
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setInt(1, device.getIddevices());
				pst.setString(2, device.getStatus());
				pst.setString(3, device.getMacaddress());
				pst.setString(4, device.getOs());
				pst.setInt(5, device.getTimestamp());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//==================================================================================================
	//IP Address =======================================================================================
	
	public static ArrayList<IpAddress> getAllIpAddresses() {
		ArrayList<IpAddress> result = new ArrayList<>();
		String sql = "select * from nssdb.ipaddress";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				result.add(new IpAddress(rst.getInt(1), rst.getString(2), rst.getInt(3), rst.getInt(4)));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertUpdateIpAddress(IpAddress ipAddress) {
		String sqlInsert = "insert into nssdb.ipaddress (address, timestamp, for_iddevice) values (?,?,?)";
		String sqlUpdate = "update nssdb.ipaddress set address=?, timestamp=? where for_iddevice=?";
		
		ArrayList<IpAddress> tempIPList = getAllIpAddresses();
		
		
		if(tempIPList.isEmpty()) {
			try {
				Connection c = DbConnection.getConnection();
				PreparedStatement pst = c.prepareStatement(sqlInsert);
				pst.setString(1, ipAddress.getIpAddress());
				pst.setInt(2, ipAddress.getTimestamp());
				pst.setInt(3, ipAddress.getFor_iddevice());
				pst.executeUpdate();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			for()
		}
	}

}
