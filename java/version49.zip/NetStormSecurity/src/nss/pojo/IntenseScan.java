package nss.pojo;

public class IntenseScan {

}
