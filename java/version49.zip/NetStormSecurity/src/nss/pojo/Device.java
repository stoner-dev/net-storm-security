package nss.pojo;

public class Device {
	
	private int iddevices;
	private String status;
	private String macaddress;
	private String os;
	private int timestamp;
	
	public Device(int iddevices, String status, String macaddress, String os, int timestamp) {
		this.iddevices = iddevices;
		this.status = status;
		this.macaddress = macaddress;
		this.os = os;
		this.timestamp = timestamp;
	}
	
	public int getIddevices() {
		return iddevices;
	}
	public void setIddevices(int iddevices) {
		this.iddevices = iddevices;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public int getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "Device [iddevices=" + iddevices + ", status=" + status + ", macaddress=" + macaddress + ", os=" + os
				+ ", timestamp=" + timestamp + "]";
	}

}