package nss.main;

import java.util.ArrayList;

import javax.swing.plaf.synth.SynthOptionPaneUI;

import nss.db.ParserDao;
import nss.function.NetworkScanner;
import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Ports;
import nss.util.ReportParser;

public class TestApp {
	
	public static void main(String[] args) {
		
		//NetworkScanner ns = new NetworkScanner();
		//ns.automaticScan();
		
		ArrayList<ArrayList<Object>> list = ReportParser.parseAutomaticScan();
		ArrayList<Device> deviceList = new ArrayList<>();
		ArrayList<IpAddress> ipAddressList = new ArrayList<>();
		ArrayList<Ports> portsList = new ArrayList<>();
		
		if(list.isEmpty()) {
			System.out.println("Is Empty");
		} else {
			for(ArrayList<Object> temp : list) {
				for(Object o : temp) {
					if(o.getClass().equals(Device.class)) {
						Device td = (Device) o;
						deviceList.add(td);
					} else if(o.getClass().equals(IpAddress.class)) {
						IpAddress ip = (IpAddress) o;
						ipAddressList.add(ip);
					} else if(o.getClass().equals(Ports.class)) {
						Ports p = (Ports) o;
						portsList.add(p);
					} else {
						continue;
					}
				}
			}
		}
		
		for(Device d : deviceList) {
			ParserDao.insertUpdateDevice(d);
		}
		
		ArrayList<Device> dbDeviceList = ParserDao.getAllDevices();
		System.out.println(dbDeviceList.size());
		for(Device temp : dbDeviceList) {
			System.out.println(temp.toString());
		}
	}

}
