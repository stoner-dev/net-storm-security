package nss.util;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReportParser {
	
	public static void parse() {
		try {
			File inputFile = new File("reports/report.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile); 
			doc.getDocumentElement().normalize();
			NodeList hostList = doc.getElementsByTagName("host");
			
			for(int i = 0; i < hostList.getLength(); i++) {
				System.out.println("---------------------------");
				System.out.println("Host " + i);
				
				Node nNode = hostList.item(i);
				NodeList nList = nNode.getChildNodes();
				
				Node nStatus = null;
				Node nIpAddress = null;
				Node nMacAddress = null;
				Node nPorts = null;
				Node nOS = null;
				
				for(int j = 0; j < nList.getLength(); j=j+2) {
					Node nnNode = nList.item(j);
					
					if(nnNode.getNodeName().equals("status")) {
						nStatus = nnNode;
					} else if(nnNode.getNodeName().equals("address") && j == 2) {
						nIpAddress = nnNode;
					} else if(nnNode.getNodeName().equals("address") && j == 4) {
						nMacAddress = nnNode;
					} else if(nnNode.getNodeName().equals("ports")) {
						nPorts = nnNode;
					} else if(nnNode.getNodeName().equals("os")) {
						nOS = nnNode;
					} else {
						continue;
					}
				}
				
				Element eStatus = (Element) nStatus;
				Element eIpAddress = (Element) nIpAddress;
				Element eMacAddress = (Element) nMacAddress;
				
				System.out.println("Status: state=" + eStatus.getAttribute("state") + ", reason=" + eStatus.getAttribute("reason"));
				System.out.println("IP-Address: address=" + eIpAddress.getAttribute("addr"));
				System.out.println("MAC-Address: address=" + eMacAddress.getAttribute("addr") + ", vendor=" + eMacAddress.getAttribute("vendor"));
				
				NodeList portList = nPorts.getChildNodes();
				NodeList osList = nOS.getChildNodes();
				
				System.out.println("Ports: ");
				for(int j = 1; j < portList.getLength(); j++) {
					Node nnNode = portList.item(j);
					Element eeElement = (Element) nnNode;
					NodeList innerPortList = nnNode.getChildNodes();
					System.out.println("Protocol: " + eeElement.getAttribute("protocol"));
					System.out.println("Port: " + eeElement.getAttribute("portid"));
					for(int k = 0; k < innerPortList.getLength(); k++) {
						Node nnnNode = innerPortList.item(k);
						Element eeeElement = (Element) nnnNode;
						if(nnnNode.getNodeName().equals("state")) {
							System.out.println("State: " + eeeElement.getAttribute("state"));
							System.out.println("Reason: " + eeeElement.getAttribute("reason"));
						} else if(nnnNode.getNodeName().equals("service")) {
							System.out.println("Name: " + eeeElement.getAttribute("name"));
							System.out.println("Version: " + eeeElement.getAttribute("version"));
						}
					}
				}
			}
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
