package test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PenetrationtestDao {
	public static void main(String[] args) {
		ArrayList<Penetrationtest> testung = PenetrationtestDao.getAll();

		for (Penetrationtest temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static Penetrationtest mapRow(ResultSet rSet) throws SQLException {
		return new Penetrationtest(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getInt(4), rSet.getString(5));
	}

	public static ArrayList<Penetrationtest> getAll() {

		ArrayList<Penetrationtest> list = new ArrayList<Penetrationtest>();

		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.Penetrationtest");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}

}
