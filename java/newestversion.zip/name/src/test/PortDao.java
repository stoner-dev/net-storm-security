package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PortDao {
	public static void main(String[] args) {
		ArrayList<Ports> testung = PortDao.getAll();

		for (Ports temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static Ports mapRow(ResultSet rSet) throws SQLException {
		return new Ports(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getString(4), rSet.getString(5),
				rSet.getInt(6), rSet.getString(7));
	}

	public static ArrayList<Ports> getAll() {

		ArrayList<Ports> list = new ArrayList<Ports>();

		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.port");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	
	
	public static ArrayList<Ports> getWhereMAc(String mac){
		ArrayList<Ports> list = new ArrayList<Ports>();
		Connection c = DbConnection.getConnection();
		try {
			PreparedStatement pst = c.prepareStatement("select * from nssdb.port where device_mac = ?", PreparedStatement.RETURN_GENERATED_KEYS);
			pst.setString(1, mac);
			ResultSet rset = pst.executeQuery();
			if(rset.next()) {
				list.add(mapRow(rset));
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
}
