package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class IntensescaninfoDao {
	public static void main(String[] args) {
		ArrayList<Intensescaninfo> testung = IntensescaninfoDao.getAll();

		for (Intensescaninfo temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static Intensescaninfo mapRow(ResultSet rSet) throws SQLException {
		return new Intensescaninfo(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getInt(4), rSet.getString(5));
	}

	public static ArrayList<Intensescaninfo> getAll() {

		ArrayList<Intensescaninfo> list = new ArrayList<Intensescaninfo>();

		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.intensescaninfo");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	
	
	public static ArrayList<Intensescaninfo> getWhereMAc(String mac){
		ArrayList<Intensescaninfo> list = new ArrayList<Intensescaninfo>();
		Connection c = DbConnection.getConnection();
		try {
			PreparedStatement pst = c.prepareStatement("select * from nssdb.intensescaninfo where device_mac = ?", PreparedStatement.RETURN_GENERATED_KEYS);
			pst.setString(1, mac);
			ResultSet rset = pst.executeQuery();
			if(rset.next()) {
				list.add(mapRow(rset));
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

}
