package nss.main;

import java.util.ArrayList;

import nss.db.AutomaticScanParserDao;
import nss.function.NetworkScanner;
import nss.function.PenetrationTest;
import nss.pojo.Device;
import nss.pojo.IpAddress;
import nss.pojo.Port;
import nss.util.ReportParser;

public class TestApp {
	
	public static void main(String[] args) {
		
//		NetworkScanner ns = new NetworkScanner();
//		ns.automaticScan();
		
//		PenetrationTest pt = new PenetrationTest();
//		pt.sshLoginCheck();
		
		ArrayList<ArrayList<Object>> list = ReportParser.parseAutomaticScan();
		ArrayList<Device> deviceList = new ArrayList<>();
		ArrayList<IpAddress> ipAddressList = new ArrayList<>();
		ArrayList<Port> portList = new ArrayList<>();
		
		if(list.isEmpty()) {
			System.out.println("Is Empty");
		} else {
			for(ArrayList<Object> temp : list) {
				for(Object o : temp) {
					if(o.getClass().equals(Device.class)) {
						Device td = (Device) o;
						deviceList.add(td);
					} else if(o.getClass().equals(IpAddress.class)) {
						IpAddress ip = (IpAddress) o;
						ipAddressList.add(ip);
					} else if(o.getClass().equals(Port.class)) {
						Port p = (Port) o;
						portList.add(p);
					} else {
						continue;
					}
				}
			}
		}
		
		for(Device d : deviceList) {
			AutomaticScanParserDao.insertUpdateDevice(d);
		}
		
		for(IpAddress ip : ipAddressList) {
			AutomaticScanParserDao.insertUpdateIpAddress(ip);
		}
		
		for(Port p : portList) {
			AutomaticScanParserDao.insertUpdatePorts(p);
		}
		
		ArrayList<Device> dbDeviceList = AutomaticScanParserDao.getAllDevices();
		ArrayList<IpAddress> dbIpList = AutomaticScanParserDao.getAllIpAddresses();
		ArrayList<Port> dbPortList = AutomaticScanParserDao.getAllPorts();
		
		for(Device temp : dbDeviceList) {
			System.out.println(temp.toString());
		}
		
		for(IpAddress temp : dbIpList) {
			System.out.println(temp.toString());
		}
		
		for(Port temp : dbPortList) {
			System.out.println(temp.toString());
		}
	}

}
