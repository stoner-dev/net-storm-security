package nss.pojo;

public class IpAddress {

	private int idipaddress;
	private String address;
	private int timestamp;
	private String device_mac;
	
	public IpAddress(int idipaddress, String address, int timestamp, String device_mac) {
		this.idipaddress = idipaddress;
		this.address = address;
		this.timestamp = timestamp;
		this.device_mac = device_mac;
	}

	public int getIdipaddress() {
		return idipaddress;
	}

	public void setIdipaddress(int idipaddress) {
		this.idipaddress = idipaddress;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public String getDevice_mac() {
		return device_mac;
	}

	public void setDevice_mac(String device_mac) {
		this.device_mac = device_mac;
	}

	@Override
	public String toString() {
		return "IpAddress [idipaddress=" + idipaddress + ", address=" + address + ", timestamp=" + timestamp
				+ ", device_mac=" + device_mac + "]";
	}

}
