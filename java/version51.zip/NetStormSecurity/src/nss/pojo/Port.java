package nss.pojo;

public class Port {
		
	private int idport;
	private String number;
	private String service;
	private String state;
	private String version;
	private int timestamp;
	private String device_mac;
	
	public Port(int idport, String number, String service, String state, String version, int timestamp, String device_mac) {
		this.idport = idport;
		this.number = number;
		this.service = service;
		this.state = state;
		this.version = version;
		this.timestamp = timestamp;
		this.device_mac = device_mac;
	}

	public int getIdport() {
		return idport;
	}

	public void setIdport(int idport) {
		this.idport = idport;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public String getDevice_mac() {
		return device_mac;
	}

	public void setDevice_mac(String device_mac) {
		this.device_mac = device_mac;
	}

	@Override
	public String toString() {
		return "Port [idport=" + idport + ", number=" + number + ", service=" + service + ", state=" + state
				+ ", version=" + version + ", timestamp=" + timestamp + ", device_mac=" + device_mac + "]";
	}
	
}
