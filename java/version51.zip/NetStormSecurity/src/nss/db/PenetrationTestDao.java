package nss.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.util.ArrayList;

import nss.pojo.IpAddress;
import nss.pojo.Penetrationtest;

public class PenetrationTestDao {
	
	public static IpAddress getIpByMac(String macAddress) {
		IpAddress result = null;
		String sql = "select * from nssdb.ipaddress where device_mac=?";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			pst.setString(1, macAddress);
			ResultSet rst = pst.executeQuery();
			if(rst.next()) {
				result = new IpAddress(rst.getInt(1), rst.getString(2), rst.getInt(3), rst.getString(4));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static void insertPenetrationData(Penetrationtest pt) {
		String sql = "insert into nssdb.penetrationtest (type, data, timestamp, device_mac) values (?,?,?,?)";
		try {
			Connection c = DbConnection.getConnection();
			PreparedStatement pst = c.prepareStatement(sql);
			pst.setString(1, pt.getType());
			pst.setString(2, pt.getData());
			pst.setInt(3, pt.getTimestamp());
			pst.setString(4, pt.getDevice_mac());
			pst.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
