package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class DeviceDao {
	public static void main(String[] args) {
		ArrayList<Device> testung = DeviceDao.getAll();

		for (Device temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static Device mapRow(ResultSet rSet) throws SQLException {
		return new Device(rSet.getString(1), rSet.getString(2), rSet.getString(3), rSet.getInt(4));
	}

	public static ArrayList<Device> getAll() {

		ArrayList<Device> list = new ArrayList<Device>();
		// list.add(new Device(100,"hallo","hallo","hallo"));

		try {
			// Connection c = DbConnection.getConnection();
			// PreparedStatement pst = c.prepareStatement();
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.device");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	public static ArrayList<Device> getWhereMAc(String mac){
		ArrayList<Device> list = new ArrayList<Device>();
		Connection c = DbConnection.getConnection();
		try {
			PreparedStatement pst = c.prepareStatement("select * from nssdb.device where macaddress = ?", PreparedStatement.RETURN_GENERATED_KEYS);
			pst.setString(1, mac);
			ResultSet rset = pst.executeQuery();
			if(rset.next()) {
				list.add(mapRow(rset));
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	

}
