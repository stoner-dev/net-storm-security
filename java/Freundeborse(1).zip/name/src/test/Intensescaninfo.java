package test;

public class Intensescaninfo {

	private int idintensescaninfo;
	private boolean is_intense;
	private String device_type;
	private String tcp_sequence_prediction;
	private int timestamp;
	private String macaddress;
	
	
	
	
	public Intensescaninfo(int idintensescaninfo, boolean is_intense, String device_type,
			String tcp_sequence_prediction, int timestamp, String macaddress) {
		super();
		this.idintensescaninfo = idintensescaninfo;
		this.is_intense = is_intense;
		this.device_type = device_type;
		this.tcp_sequence_prediction = tcp_sequence_prediction;
		this.timestamp = timestamp;
		this.macaddress = macaddress;
	}



	public int getIdintensescaninfo() {
		return idintensescaninfo;
	}
	public void setIdintensescaninfo(int idintensescaninfo) {
		this.idintensescaninfo = idintensescaninfo;
	}
	public boolean isIs_intense() {
		return is_intense;
	}
	public void setIs_intense(boolean is_intense) {
		this.is_intense = is_intense;
	}
	public String getDevice_type() {
		return device_type;
	}
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	public String getTcp_sequence_prediction() {
		return tcp_sequence_prediction;
	}
	public void setTcp_sequence_prediction(String tcp_sequence_prediction) {
		this.tcp_sequence_prediction = tcp_sequence_prediction;
	}
	public int getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	@Override
	public String toString() {
		return "Intensescaninfo [idintensescaninfo=" + idintensescaninfo + ", is_intense=" + is_intense
				+ ", device_type=" + device_type + ", tcp_sequence_prediction=" + tcp_sequence_prediction
				+ ", timestamp=" + timestamp + ", macaddress=" + macaddress + "]";
	}
	
	
}
