package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class IpAddressDao {
	public static void main(String[] args) {
		ArrayList<IpAddress> testung = IpAddressDao.getAll();

		for (IpAddress temp : testung) {
			System.out.println(temp.toString());
		}
	}

	private static IpAddress mapRow(ResultSet rSet) throws SQLException {
		return new IpAddress(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getString(4));
	}

	public static ArrayList<IpAddress> getAll() {

		ArrayList<IpAddress> list = new ArrayList<IpAddress>();

		try {
			ResultSet rSet = DbConnection.executeQuery("select * from nssdb.ipaddress");

			while (rSet.next()) {
				list.add(mapRow(rSet));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	
	public static ArrayList<IpAddress> getWhereMAc(String mac){
		ArrayList<IpAddress> list = new ArrayList<IpAddress>();
		Connection c = DbConnection.getConnection();
		try {
			PreparedStatement pst = c.prepareStatement("select * from nssdb.ipaddress where macaddress = ?", PreparedStatement.RETURN_GENERATED_KEYS);
			pst.setString(1, mac);
			ResultSet rset = pst.executeQuery();
			if(rset.next()) {
				list.add(mapRow(rset));
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

}
