package test;

public class IpAddress {

	private int idipaddress;
	private String ipaddress;
	private String timestamp;
	private String macaddress;
	
	

	public IpAddress(int idipaddress, String ipadress, String timestamp, String macaddress) {
		super();
		this.idipaddress = idipaddress;
		this.ipaddress = ipadress;
		this.timestamp = timestamp;
		this.macaddress = macaddress;
	}
	
	

	public int getIdipaddress() {
		return idipaddress;
	}



	public void setIdipaddress(int idipaddress) {
		this.idipaddress = idipaddress;
	}



	public String getIpaddress() {
		return ipaddress;
	}



	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}



	public String getTimestamp() {
		return timestamp;
	}



	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}



	public String getMacaddress() {
		return macaddress;
	}



	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}



	@Override
	public String toString() {
		return "IpAddress [idipaddress=" + idipaddress + ", ipaddress=" + ipaddress + ", timestamp=" + timestamp + ", macaddress="
				+ macaddress + "]";
	}
	
	
	
}
